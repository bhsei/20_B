from init import createApp

app=createApp()

if __name__ == "__main__":
    app.run(host="172.16.4.195",port=5000)